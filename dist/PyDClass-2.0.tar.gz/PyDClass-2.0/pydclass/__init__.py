"""
Welcome to PyDClass
No, there isn't an easter egg :(
"""
